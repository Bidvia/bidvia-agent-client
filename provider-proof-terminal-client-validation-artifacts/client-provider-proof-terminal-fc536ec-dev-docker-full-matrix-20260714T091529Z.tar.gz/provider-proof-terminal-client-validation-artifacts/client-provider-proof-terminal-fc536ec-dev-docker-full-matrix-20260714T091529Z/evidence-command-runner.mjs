import { spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { relative, resolve } from 'node:path';

const [commandsPath, logPath, exitCodePath, command, ...args] = process.argv.slice(2);

if (!commandsPath || !logPath || !exitCodePath || !command) {
  throw new Error('usage: evidence-command-runner <commands-json> <log> <exit-code> <command> [...args]');
}

const startedAt = new Date().toISOString();
const result = spawnSync(command, args, {
  cwd: process.cwd(),
  encoding: 'utf8',
  env: process.env,
});
const finishedAt = new Date().toISOString();
const exitCode = result.error ? 127 : (result.status ?? 1);
const workspace = resolve(process.cwd());
const redactText = (value) => value
  .replaceAll(workspace, '[WORKSPACE]')
  .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[REDACTED_EMAIL]')
  .replace(/\b(?:admin-session|sess)-(?!id\b)[A-Za-z0-9._:-]+\b/g, '[REDACTED]')
  .replace(/\b(?:Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+/gi, '[REDACTED_AUTH]');
const safeArgs = args.map((arg, index) => {
  const previous = args[index - 1] ?? '';
  return /password|token|secret|authorization/i.test(previous) ? '[REDACTED]' : redactText(arg);
});
const output = redactText(`${result.stdout ?? ''}${result.stderr ?? ''}`);

writeFileSync(logPath, output);
writeFileSync(exitCodePath, `${exitCode}\n`);

let commands = [];
try {
  commands = JSON.parse(readFileSync(commandsPath, 'utf8'));
} catch (error) {
  if (!(error instanceof Error) || !error.message.includes('ENOENT')) {
    throw error;
  }
}

const evidenceRoot = resolve(process.env.EVIDENCE_ROOT ?? '.');
commands.push({
  command: [command, ...safeArgs].join(' '),
  working_directory: '[WORKSPACE]',
  started_at: startedAt,
  finished_at: finishedAt,
  exit_code: exitCode,
  log_ref: relative(evidenceRoot, resolve(logPath)),
});
writeFileSync(commandsPath, `${JSON.stringify(commands, null, 2)}\n`);

if (result.error) {
  process.stderr.write(`${result.error.message}\n`);
}
process.exit(exitCode);
