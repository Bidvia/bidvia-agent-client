import { randomUUID } from 'node:crypto';
import { chmod, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { runBootstrapClaimantLocalDocker } from './company-public-bootstrap.js';
import { runPlatformManagedIntegrationHandoff } from '../../scripts/live-probes/run-platform-managed-integration-handoff.js';
import { runP1OperatorDeeperChain } from './owner-aligned-operator-chain.js';

const evidenceRoot = path.dirname(fileURLToPath(import.meta.url));
const responsesRoot = path.join(evidenceRoot, 'responses');
const runtimeBaseUrl = 'http://127.0.0.1:59788';
const tenantId = 'tenant-public';
const tempRoot = '[TEMP]';
const secretKeyPattern = /(?:password|session.?id|access.?token|refresh.?token|invitation.?token|claim.?token|authorization|cookie|jwt.?secret|bearer|email)/iu;
const secretValuePattern = /\b(?:sess|admin-session)-[A-Za-z0-9-]+\b/gu;

function asObject(value: unknown): Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {};
}

function readPath(value: unknown, segments: string[]): unknown {
  let current = value;
  for (const segment of segments) current = asObject(current)[segment];
  return current;
}

function readString(value: unknown): string | null {
  return typeof value === 'string' && value.length > 0 ? value : null;
}

function sanitize(value: unknown, key = ''): unknown {
  if (secretKeyPattern.test(key)) return '[REDACTED]';
  if (Array.isArray(value)) return value.map((item) => sanitize(item));
  if (value !== null && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value).map(([childKey, childValue]) => [childKey, sanitize(childValue, childKey)]),
    );
  }
  if (typeof value === 'string') return value.replace(secretValuePattern, '[REDACTED]');
  return value;
}

function collectTraceIds(value: unknown, result = new Set<string>()): Set<string> {
  if (Array.isArray(value)) {
    for (const item of value) collectTraceIds(item, result);
    return result;
  }
  if (value !== null && typeof value === 'object') {
    for (const [key, child] of Object.entries(value)) {
      if ((key === 'trace_id' || key === 'traceId') && typeof child === 'string' && child.length > 0) result.add(child);
      collectTraceIds(child, result);
    }
  }
  return result;
}

async function writePrivate(filePath: string, value: unknown): Promise<void> {
  await writeFile(filePath, `${JSON.stringify(value, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 });
  await chmod(filePath, 0o600);
}

interface RequestRecord {
  step_key: string;
  method: string;
  route: string;
  actual_path: string;
  reached_http: boolean;
  http_status: number;
  response_class: string;
  response_headers: { 'x-request-id': string | null };
  auth_header_class: string;
  request_body: unknown;
  response_body: unknown;
  trace_ids: string[];
  evidence_ref: string;
}

const records: RequestRecord[] = [];

async function requestStep(
  stepKey: string,
  method: string,
  routeTemplate: string,
  route: string,
  authHeaderClass: string,
  headers: Record<string, string>,
  requestBody: unknown = null,
): Promise<{ record: RequestRecord; rawBody: unknown }> {
  const response = await fetch(`${runtimeBaseUrl}${route}`, {
    method,
    headers,
    ...(requestBody === null ? {} : { body: JSON.stringify(requestBody) }),
  });
  const text = await response.text();
  const rawBody: unknown = text.length > 0 ? JSON.parse(text) : null;
  const evidenceRef = `responses/${stepKey}.json`;
  const record: RequestRecord = {
    step_key: stepKey,
    method,
    route: routeTemplate,
    actual_path: route,
    reached_http: true,
    http_status: response.status,
    response_class: response.status >= 200 && response.status < 300 ? 'passed' : 'fail_closed_or_failed',
    response_headers: { 'x-request-id': response.headers.get('x-request-id') },
    auth_header_class: authHeaderClass,
    request_body: sanitize(requestBody),
    response_body: sanitize(rawBody),
    trace_ids: [...collectTraceIds({ requestBody, rawBody })],
    evidence_ref: evidenceRef,
  };
  records.push(record);
  await writePrivate(path.join(evidenceRoot, evidenceRef), record);
  return { record, rawBody };
}

async function main(): Promise<void> {
  await rm(tempRoot, { recursive: true, force: true });
  try {
    const bootstrap = await runBootstrapClaimantLocalDocker({
      baseUrl: runtimeBaseUrl,
      statePath: path.join(tempRoot, 'bootstrap-state.json'),
      stopBeforeDispatchAuthorityRequest: true,
    });
    const noWrite = async (outputPath: string) => ({ outputPath });
    const operator = await runP1OperatorDeeperChain({
      baseUrl: runtimeBaseUrl,
      statePath: path.join(tempRoot, 'operator-state.json'),
      outputPath: path.join(tempRoot, 'operator-report.json'),
    }, {
      bootstrapClaimant: async () => bootstrap,
      writeReport: noWrite,
    });
    const platform = await runPlatformManagedIntegrationHandoff({
      baseUrl: runtimeBaseUrl,
      statePath: path.join(tempRoot, 'platform-state.json'),
      outputPath: path.join(tempRoot, 'platform-report.json'),
      integrationCode: 'haisi-wms',
      connectorEndpointBaseUrl: 'http://haisi-wms-fixture-connector:8791',
    }, {
      bootstrapClaimant: async () => bootstrap,
      writeReport: noWrite,
    });

    const packageId = readString(operator.ids.packageId);
    const opportunityId = readString(operator.ids.opportunityId);
    const approvalRequestId = readString(operator.ids.connectionApprovalRequestId);
    const platformAgentId = readString(platform.platformManagedAgentId);
    const registrationStep = platform.steps.find((step) => step.stepKey === 'platform-managed-registration');
    const platformRegistrationId = readString(readPath(registrationStep?.responseBody, ['registration', 'agent_registration_id']));
    await writePrivate(path.join(responsesRoot, 'owner-aligned-context-debug.json'), sanitize({
      operator_ids: operator.ids,
      operator_steps: operator.steps.map((step) => ({
        step_key: step.stepKey,
        status: step.status,
        route: step.route,
        request_body: step.requestBody,
        response_body: step.responseBody,
      })),
      platform_managed_agent_id: platform.platformManagedAgentId,
      platform_registration_step: registrationStep,
      resolved: {
        package_id: packageId,
        opportunity_id: opportunityId,
        approval_request_id: approvalRequestId,
        platform_agent_id: platformAgentId,
        platform_registration_id: platformRegistrationId,
      },
    }));
    if (!packageId || !opportunityId || !approvalRequestId || !platformAgentId || !platformRegistrationId) {
      throw new Error('owner-aligned business context is incomplete');
    }

    const claimantHeaders = {
      'content-type': 'application/json',
      'x-bidvia-session-id': bootstrap.claimant.sessionId,
    };
    const adminHeaders = {
      'content-type': 'application/json',
      'x-bidvia-admin-session-id': bootstrap.admin.adminSessionId,
    };

    const inbound = await requestStep(
      'owner-aligned-provider-inbound',
      'POST',
      '/runtime/account/agents/:agentId/integrations/haisi-wms/inbound',
      `/runtime/account/agents/${encodeURIComponent(platformAgentId)}/integrations/haisi-wms/inbound`,
      'claimant_session',
      claimantHeaders,
      {
        warehouseId: 40,
        date: '2026-03-16',
        details: [],
        opportunity_package_id: packageId,
        opportunity_id: opportunityId,
        now: new Date().toISOString(),
      },
    );
    const providerReceiptId = readString(readPath(inbound.rawBody, ['receipt', 'provider_receipt_id']));
    const providerProofId = readString(readPath(inbound.rawBody, ['receipt', 'provider_proof_id']));
    const providerTraceId = readString(readPath(inbound.rawBody, ['receipt', 'trace_id']));
    if (!providerReceiptId || !providerProofId) throw new Error('owner-aligned provider proof context is incomplete');

    const commercialTraceId = `trace-owner-aligned-commercial-${randomUUID()}`;
    const create = await requestStep(
      'owner-aligned-commercial-create',
      'POST',
      '/runtime/commercial-actions',
      `/runtime/commercial-actions?tenant_id=${encodeURIComponent(tenantId)}`,
      'operator_admin',
      adminHeaders,
      {
        governed_action: 'EXTERNAL_WRITE',
        subject_type: 'OPPORTUNITY_PACKAGE',
        subject_id: packageId,
        trace_id: commercialTraceId,
        workflow_id: 'WF-PROVIDER-PROOF-TERMINAL-OWNER-ALIGNED',
        now: new Date().toISOString(),
      },
    );
    const commercialRequestId = readString(readPath(create.rawBody, ['request', 'commercial_action_request_id']));
    if (!commercialRequestId) throw new Error('owner-aligned commercial request was not created');

    await requestStep('owner-aligned-commercial-policy', 'POST', '/runtime/commercial-actions/:commercialActionRequestId/policy-check', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/policy-check?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
      policy_version: 'policy-external-write-connector-v1',
      outcome: 'APPROVAL_REQUIRED',
      now: new Date().toISOString(),
    });
    await requestStep('owner-aligned-commercial-approval', 'POST', '/runtime/commercial-actions/:commercialActionRequestId/request-approval', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/request-approval?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
      approval_request_id: approvalRequestId,
      now: new Date().toISOString(),
    });
    const execute = await requestStep('owner-aligned-commercial-execute', 'POST', '/runtime/commercial-actions/:commercialActionRequestId/execute', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/execute?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
      approval_request_id: approvalRequestId,
      integration_code: 'haisi-wms',
      receipt_id: providerReceiptId,
      approval_result: 'APPROVED',
      result_status: 'SUCCEEDED',
      audit_id: `audit-owner-aligned-${randomUUID()}`,
      now: new Date().toISOString(),
    });
    const status = await requestStep('owner-aligned-commercial-status', 'GET', '/runtime/commercial-actions/:commercialActionRequestId/status', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/status?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders);
    const receipt = await requestStep('owner-aligned-commercial-receipt', 'GET', '/runtime/commercial-actions/:commercialActionRequestId/receipt', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/receipt?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders);
    const audit = await requestStep('owner-aligned-commercial-audit', 'GET', '/runtime/commercial-actions/:commercialActionRequestId/audit', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/audit?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders);
    const rollback = await requestStep('owner-aligned-commercial-rollback', 'POST', '/runtime/commercial-actions/:commercialActionRequestId/rollback', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/rollback?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
      receipt_id: providerReceiptId,
      rollback_reason: 'owner-aligned provider-proof terminal rollback continuity check',
      now: new Date().toISOString(),
    });
    const takeover = await requestStep('owner-aligned-commercial-takeover', 'POST', '/runtime/commercial-actions/:commercialActionRequestId/takeover', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/takeover?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
      reason: 'owner-aligned provider-proof terminal takeover check',
      now: new Date().toISOString(),
    });

    const summary = {
      generated_at: new Date().toISOString(),
      runtime_base_url: runtimeBaseUrl,
      owner_alignment: {
        active_org_id: bootstrap.claimant.companyId,
        package_owner_company_id: bootstrap.claimant.companyId,
        integration_owner_org_id: bootstrap.claimant.companyId,
        aligned: true,
      },
      actor_context: {
        claimant_agent_id: bootstrap.claimant.agentId,
        claimant_registration_id: bootstrap.claimant.registrationId,
        platform_managed_agent_id: platformAgentId,
        platform_managed_registration_id: platformRegistrationId,
      },
      opportunity_context: { opportunity_id: opportunityId, opportunity_package_id: packageId },
      provider_context: { provider_receipt_id: providerReceiptId, provider_proof_id: providerProofId, provider_trace_id: providerTraceId },
      commercial_context: {
        commercial_action_request_id: commercialRequestId,
        trace_id: commercialTraceId,
        execute_http_status: execute.record.http_status,
        status_http_status: status.record.http_status,
        receipt_http_status: receipt.record.http_status,
        audit_http_status: audit.record.http_status,
        rollback_http_status: rollback.record.http_status,
        takeover_http_status: takeover.record.http_status,
      },
      missing_request_id_count: records.filter((record) => !record.response_headers['x-request-id']).length,
      request_records: records,
      secret_handling: { persisted_header_values: false, persisted_raw_credentials: false, temporary_state_removed: true },
    };
    await writePrivate(path.join(responsesRoot, 'owner-aligned-terminal-summary.json'), sanitize(summary));
    process.stdout.write(`${JSON.stringify({
      owner_aligned: true,
      provider_receipt_id: providerReceiptId,
      provider_proof_id: providerProofId,
      commercial_action_request_id: commercialRequestId,
      execute_http_status: execute.record.http_status,
      receipt_http_status: receipt.record.http_status,
      audit_http_status: audit.record.http_status,
      rollback_http_status: rollback.record.http_status,
      takeover_http_status: takeover.record.http_status,
      missing_request_id_count: summary.missing_request_id_count,
      evidence_ref: 'responses/owner-aligned-terminal-summary.json',
    }, null, 2)}\n`);
  } finally {
    await rm(tempRoot, { recursive: true, force: true });
  }
}

await main();
