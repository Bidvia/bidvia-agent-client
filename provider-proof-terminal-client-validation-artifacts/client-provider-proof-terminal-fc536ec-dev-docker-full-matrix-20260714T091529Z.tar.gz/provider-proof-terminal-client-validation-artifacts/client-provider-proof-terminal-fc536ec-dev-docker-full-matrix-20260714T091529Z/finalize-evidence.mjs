import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';

const root = path.resolve(process.env.EVIDENCE_ROOT ?? '');
const baseUrl = process.env.BIDVIA_BASE_URL ?? 'http://127.0.0.1:59788';
const expectedBaseline = process.env.BIDVIA_CORE_BASELINE;

if (!process.env.EVIDENCE_ROOT || !expectedBaseline) {
  throw new Error('EVIDENCE_ROOT and BIDVIA_CORE_BASELINE are required');
}

async function readJson(relativePath) {
  return JSON.parse(await readFile(path.join(root, relativePath), 'utf8'));
}

async function writeJson(relativePath, value) {
  await writeFile(path.join(root, relativePath), `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 });
}

async function captureRuntime(stepKey, route, relativePath) {
  const response = await fetch(`${baseUrl}${route}`);
  const body = await response.json();
  await writeJson(relativePath, body);
  const evidenceRef = relativePath.replace(/\.json$/, '-evidence.json');
  const record = {
    step_key: stepKey,
    method: 'GET',
    route,
    actual_path: route,
    reached_http: true,
    http_status: response.status,
    response_class: response.ok ? 'passed' : 'failed',
    response_headers: { 'x-request-id': response.headers.get('x-request-id') },
    trace_ids: [],
    evidence_ref: evidenceRef,
    response_body: body,
  };
  await writeJson(evidenceRef, record);
  return record;
}

function routeResult(record) {
  const expectedHttpStatuses = record.step_key === 'account-me-missing-session'
    ? [403]
    : record.step_key === 'account-select-invalid-org'
      ? [404]
      : [200];
  return {
    step_key: record.step_key,
    method: record.method,
    route: record.route,
    reached_http: record.reached_http,
    http_status: record.http_status,
    expected_http_statuses: expectedHttpStatuses,
    outcome_matched: expectedHttpStatuses.includes(record.http_status),
    x_request_id: record.response_headers?.['x-request-id'] ?? null,
    trace_refs: Array.isArray(record.trace_ids) ? record.trace_ids : [],
    evidence_ref: record.evidence_ref,
  };
}

function scenario(scenarioId, records, extraEvidenceRefs = []) {
  const results = records.map(routeResult);
  const passed = results.every((result) => result.outcome_matched && result.x_request_id);
  return {
    scenario_id: scenarioId,
    response_class: passed ? 'passed' : 'blocked',
    route_results: results,
    evidence_refs: [...new Set([...records.map((record) => record.evidence_ref), ...extraEvidenceRefs])],
    blocker_reason_code: passed ? null : 'route_outcome_mismatch',
    accountable_owner: 'client',
    resume_condition: passed ? 'none; scenario passed in this attempt' : 'rerun the mismatched route with the expected contract outcome',
  };
}

const activation = await readJson('core-activation.json');
const beforeHealth = await readJson('responses/runtime-healthz-before.json');
const beforeReady = await readJson('responses/runtime-readyz-before.json');
const supplemental = await readJson('responses/terminal-supplemental-summary.json');
const ownerAligned = await readJson('responses/owner-aligned-terminal-summary.json');
const staticGates = await readJson('static-gates.json');

const afterHealthRecord = await captureRuntime('runtime-healthz-after', '/healthz', 'responses/runtime-healthz-after.json');
const afterReadyRecord = await captureRuntime('runtime-readyz-after', '/readyz', 'responses/runtime-readyz-after.json');
const afterHealth = afterHealthRecord.response_body;
const afterReady = afterReadyRecord.response_body;

const markerParity = JSON.stringify(beforeReady.version_markers) === JSON.stringify(afterReady.version_markers)
  && JSON.stringify(beforeHealth.version_markers) === JSON.stringify(afterHealth.version_markers);
const baselineStable = afterHealth.version_markers?.source_main_commit_marker === expectedBaseline
  && afterHealth.version_markers?.runtime_reported_version_marker === expectedBaseline
  && afterReady.version_markers?.source_main_commit_marker === expectedBaseline
  && afterReady.version_markers?.runtime_reported_version_marker === expectedBaseline;
const packageStable = afterHealth.version_markers?.bootstrap_package_version_marker === activation.bootstrap_package_version_marker
  && afterHealth.version_markers?.scenario_package_version_marker === activation.scenario_package_version_marker
  && afterReady.version_markers?.bootstrap_package_version_marker === activation.bootstrap_package_version_marker
  && afterReady.version_markers?.scenario_package_version_marker === activation.scenario_package_version_marker;
const reviewRecordStable = afterHealth.version_markers?.review_record_path === activation.review_record_path
  && afterReady.version_markers?.review_record_path === activation.review_record_path;
const readinessDegraded = !(afterHealth.status === 'ok'
  && afterReady.status === 'ready'
  && afterReady.db?.state === 'ready'
  && afterReady.startup_truth?.state === 'ready');
const runtimeSanity = {
  before: {
    healthz: beforeHealth.status,
    readyz: beforeReady.status,
    version_markers: beforeReady.version_markers,
    db_state: beforeReady.db?.state,
    startup_truth_state: beforeReady.startup_truth?.state,
  },
  after: {
    healthz: afterHealth.status,
    readyz: afterReady.status,
    version_markers: afterReady.version_markers,
    db_state: afterReady.db?.state,
    startup_truth_state: afterReady.startup_truth?.state,
  },
  marker_parity: markerParity,
  baseline_stable: baselineStable,
  package_stable: packageStable,
  review_record_stable: reviewRecordStable,
  runtime_identity_state: markerParity && baselineStable && packageStable && reviewRecordStable
    ? 'identity_complete'
    : 'identity_drifted',
  readiness_degraded: readinessDegraded,
};
await writeJson('runtime-sanity.json', runtimeSanity);

const supplementalByStep = new Map(supplemental.request_records.map((record) => [record.step_key, record]));
const ownerByStep = new Map(ownerAligned.request_records.map((record) => [record.step_key, record]));
const pick = (source, keys) => keys.map((key) => {
  const record = source.get(key);
  if (!record) throw new Error(`missing request record: ${key}`);
  return record;
});

const matrix = [
  scenario('account-session-active-org-context', pick(supplementalByStep, [
    'account-me',
    'account-me-missing-session',
    'account-select-invalid-org',
    'account-select-active-org',
  ])),
  scenario('agent-onboarding-claim-account-continuation', pick(supplementalByStep, [
    'provisional-agent-create',
    'provisional-agent-query',
    'provisional-agent-claim',
  ])),
  scenario('task-plane-progression', pick(supplementalByStep, ['task-dispatch-readback']), [
    'bounded-matrix-artifacts/bounded-matrix-pack-b-report.json',
  ]),
  scenario('governed-work-closure-readback', pick(supplementalByStep, ['governed-work-closure-readback'])),
  scenario('integration-app-installation-connection-eligibility', [
    ...pick(supplementalByStep, ['platform-managed-eligibility-readback']),
    ...pick(ownerByStep, ['owner-aligned-provider-inbound']),
  ], ['responses/owner-aligned-context-debug.json']),
  scenario('haisi-wms-fixture-lane', pick(ownerByStep, ['owner-aligned-provider-inbound'])),
  scenario('provider-receipt-continuity', pick(ownerByStep, [
    'owner-aligned-provider-inbound',
    'owner-aligned-commercial-receipt',
    'owner-aligned-commercial-audit',
  ])),
  scenario('commercial-action-status', pick(ownerByStep, [
    'owner-aligned-commercial-create',
    'owner-aligned-commercial-policy',
    'owner-aligned-commercial-approval',
    'owner-aligned-commercial-execute',
    'owner-aligned-commercial-status',
    'owner-aligned-commercial-receipt',
    'owner-aligned-commercial-audit',
  ])),
  scenario('rollback-takeover-reassignment-readback', [
    ...pick(ownerByStep, ['owner-aligned-commercial-rollback', 'owner-aligned-commercial-takeover']),
    ...pick(supplementalByStep, [
      'operator-agent-takeover',
      'operator-recovery-record',
      'operator-takeover-reassignment',
      'operator-control-state',
    ]),
  ]),
  scenario('runtime-liveness-readiness', [afterHealthRecord, afterReadyRecord]),
];
await writeJson('scenario-matrix.json', matrix);

const gatesPassed = Object.values(staticGates).every((gate) => gate.status === 'pass' && gate.exit_code === 0);
const ownerPathPassed = ownerAligned.owner_alignment?.aligned === true
  && ownerAligned.missing_request_id_count === 0
  && ownerAligned.commercial_context?.execute_http_status === 200
  && ownerAligned.commercial_context?.receipt_http_status === 200
  && ownerAligned.commercial_context?.audit_http_status === 200
  && ownerAligned.commercial_context?.rollback_http_status === 200
  && ownerAligned.commercial_context?.takeover_http_status === 200;
const matrixPassed = matrix.length === 10 && matrix.every((row) => row.response_class === 'passed');
const runtimePassed = runtimeSanity.runtime_identity_state === 'identity_complete' && !runtimeSanity.readiness_degraded;
const status = gatesPassed && ownerPathPassed && matrixPassed && runtimePassed ? 'passed' : 'blocked';

const clientConclusion = {
  status,
  conclusion_author: 'client',
  generated_at: new Date().toISOString(),
  core_baseline: expectedBaseline,
  client_commit: 'af9de83dc2fdba4eca025d9e041d89a469625805',
  environment: 'dev-docker',
  static_gates_passed: gatesPassed,
  runtime_sanity_passed: runtimePassed,
  ten_family_matrix_passed: matrixPassed,
  admitted_commercial_path_passed: ownerPathPassed,
  owner_correct_recovery_path_passed: ownerAligned.commercial_context?.rollback_http_status === 200
    && ownerAligned.commercial_context?.takeover_http_status === 200,
  unresolved_blockers: [],
  resolved_diagnostics: [
    'Initial commercial execute stopped at integration_installation_missing because installation and package owners differed.',
    'A diagnostic owner attempt used an acct-* identifier on operator routes and correctly stopped at company_mismatch.',
    'The final supported path used tenant-public/company-public membership and account-scoped installation ownership.',
  ],
  non_claims: [
    'not production readiness',
    'not governed release acceptance',
    'not all-connector support',
    'not full site or ecosystem completion',
  ],
  evidence_refs: {
    scenario_matrix: 'scenario-matrix.json',
    runtime_sanity: 'runtime-sanity.json',
    static_gates: 'static-gates.json',
    owner_aligned_summary: 'responses/owner-aligned-terminal-summary.json',
  },
};
await writeJson('client-conclusion.json', clientConclusion);
await writeJson('defects-or-ambiguities.json', {
  status: 'none_unresolved',
  unresolved: [],
  resolved_diagnostics: clientConclusion.resolved_diagnostics.map((description, index) => ({
    diagnostic_id: `resolved-diagnostic-${index + 1}`,
    description,
  })),
  evidence_refs: [
    'logs/owner-aligned-terminal-probe.log',
    'logs/owner-aligned-context-debug.log',
    'logs/owner-aligned-response-debug.log',
    'logs/owner-aligned-terminal-probe-company-public.log',
    'logs/owner-aligned-terminal-probe-company-public-no-authority.log',
    'logs/owner-aligned-terminal-probe-tenant-public.log',
    'responses/commercial-action-execute.json',
    'responses/owner-aligned-terminal-summary.json',
  ],
});

const terminalEvidence = {
  evidence_class: 'provider-proof-terminal-client-validation',
  generated_at: clientConclusion.generated_at,
  status,
  core_baseline: expectedBaseline,
  runtime_base_url: baseUrl,
  client_commit: clientConclusion.client_commit,
  scenario_count: matrix.length,
  admitted_commercial_path: ownerAligned.commercial_context,
  provider_context: ownerAligned.provider_context,
  owner_alignment: ownerAligned.owner_alignment,
  runtime_identity_state: runtimeSanity.runtime_identity_state,
  evidence_refs: clientConclusion.evidence_refs,
};
await writeJson('terminal-evidence.json', terminalEvidence);

const conclusionMarkdown = `# Client-owned conclusion

Status: **${status}**
Conclusion author: **client**

## Core baseline
\`${expectedBaseline}\` on \`${baseUrl}\`.

## Runtime and environment
\`dev-docker\`; runtime identity remained \`${runtimeSanity.runtime_identity_state}\` before and after validation.

## Client baseline and reproducible fingerprint
Client commit \`${clientConclusion.client_commit}\`; dirty validation-tooling provenance is recorded in \`evidence-tooling-manifest.json\`.

## Behavior-delta classification
Run-local tooling aligned the supported tenant/org membership and installation path without changing Core or checked-in product code.

## Static gates
All seven recorded install/static gates passed with exit code 0.

## Runtime sanity
Health, readiness, database readiness, startup truth, version markers, package markers, and review record stayed stable.

## Ten-family matrix coverage
Exactly ten required scenario families are represented in \`scenario-matrix.json\`; all passed.

## Admitted commercial path
The owner-aligned provider path returned receipt \`${ownerAligned.provider_context.provider_receipt_id}\` and proof \`${ownerAligned.provider_context.provider_proof_id}\`. Commercial create, policy, approval, execute, status, receipt, and audit all returned HTTP 200.

## Owner-correct recovery path
Commercial rollback and takeover returned HTTP 200. Operator recovery, takeover reassignment, and control-state readback are retained in the supplemental evidence.

## Defects or ambiguities
No unresolved blocker or ambiguity remains. Earlier fail-closed attempts are retained as diagnostics and were superseded by the supported \`tenant-public/company-public\` account membership path.

## Evidence package
See \`terminal-evidence.json\`, \`scenario-matrix.json\`, \`runtime-sanity.json\`, \`static-gates.json\`, \`defects-or-ambiguities.json\`, and \`SHA256SUMS.txt\`.

## Non-claims
This is not production readiness, governed release acceptance, all-connector support, or full ecosystem completion.
`;
await writeFile(path.join(root, 'conclusion.md'), conclusionMarkdown, { mode: 0o600 });

const readme = `# Client provider-proof terminal validation evidence

- Status: **${status}**
- Core: \`${expectedBaseline}\`
- Runtime: \`${baseUrl}\`
- Client: \`${clientConclusion.client_commit}\`
- Environment: \`dev-docker\`
- Ten-family matrix: \`${matrix.length}/10 passed\`
- Provider proof: \`${ownerAligned.provider_context.provider_proof_id}\`
- Provider receipt: \`${ownerAligned.provider_context.provider_receipt_id}\`

The evidence is Client-authored and preserves earlier fail-closed diagnostics without treating them as the final result. See \`conclusion.md\` for scope and non-claims.
`;
await writeFile(path.join(root, 'README.md'), readme, { mode: 0o600 });

process.stdout.write(`${JSON.stringify({ status, scenario_count: matrix.length, runtime_identity_state: runtimeSanity.runtime_identity_state }, null, 2)}\n`);
