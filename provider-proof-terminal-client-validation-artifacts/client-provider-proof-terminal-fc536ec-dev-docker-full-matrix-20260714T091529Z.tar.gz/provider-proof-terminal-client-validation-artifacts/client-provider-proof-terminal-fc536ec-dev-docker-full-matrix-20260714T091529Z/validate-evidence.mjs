import { createHash } from 'node:crypto';
import { readdir, readFile, stat, writeFile } from 'node:fs/promises';
import path from 'node:path';

const root = path.resolve(process.env.EVIDENCE_ROOT ?? '');
const mode = process.argv[2];

if (!process.env.EVIDENCE_ROOT || !mode) {
  throw new Error('EVIDENCE_ROOT and validation mode are required');
}

async function readJson(relativePath) {
  return JSON.parse(await readFile(path.join(root, relativePath), 'utf8'));
}

async function writeJson(relativePath, value) {
  await writeFile(path.join(root, relativePath), `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 });
}

async function listFiles(directory = root) {
  const entries = await readdir(directory, { withFileTypes: true });
  const nested = await Promise.all(entries.map(async (entry) => {
    const absolutePath = path.join(directory, entry.name);
    return entry.isDirectory() ? listFiles(absolutePath) : [absolutePath];
  }));
  return nested.flat().sort();
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function resolveInsideRoot(ref, label) {
  assert(typeof ref === 'string' && ref.trim().length > 0, `${label}: empty ref`);
  assert(!path.isAbsolute(ref) && !ref.includes('..'), `${label}: unsafe ref ${ref}`);
  const resolved = path.resolve(root, ref);
  assert(resolved === root || resolved.startsWith(`${root}${path.sep}`), `${label}: escaped root ${ref}`);
  return resolved;
}

async function validateMatrix() {
  const required = [
    'account-session-active-org-context',
    'agent-onboarding-claim-account-continuation',
    'task-plane-progression',
    'governed-work-closure-readback',
    'integration-app-installation-connection-eligibility',
    'haisi-wms-fixture-lane',
    'provider-receipt-continuity',
    'commercial-action-status',
    'rollback-takeover-reassignment-readback',
    'runtime-liveness-readiness',
  ];
  const allowed = new Set(['passed', 'blocked', 'ambiguous', 'expected-fail-closed']);
  const rows = await readJson('scenario-matrix.json');
  assert(Array.isArray(rows) && rows.length === required.length, 'scenario matrix must contain exactly ten rows');
  const ids = rows.map((row) => row.scenario_id);
  assert(new Set(ids).size === required.length && required.every((id) => ids.includes(id)), 'scenario matrix IDs are incomplete or duplicated');
  for (const row of rows) {
    assert(allowed.has(row.response_class), `invalid response class: ${row.scenario_id}`);
    assert(row.response_class === 'passed', `unresolved scenario: ${row.scenario_id}`);
    assert(row.accountable_owner && row.resume_condition, `missing owner/resume condition: ${row.scenario_id}`);
    assert(Array.isArray(row.route_results) && row.route_results.length > 0, `missing route results: ${row.scenario_id}`);
    assert(Array.isArray(row.evidence_refs) && row.evidence_refs.length > 0, `missing evidence refs: ${row.scenario_id}`);
    for (const ref of row.evidence_refs) {
      const resolved = resolveInsideRoot(ref, `${row.scenario_id} evidence_ref`);
      assert((await stat(resolved)).isFile(), `${row.scenario_id}: missing file ${ref}`);
    }
    for (const result of row.route_results) {
      assert(typeof result.reached_http === 'boolean', `route result missing reached_http: ${row.scenario_id}/${result.step_key}`);
      if (result.reached_http) {
        assert(typeof result.x_request_id === 'string' && result.x_request_id.length > 0, `reached HTTP row missing x-request-id: ${row.scenario_id}/${result.step_key}`);
        const expectedHttpStatuses = result.step_key === 'account-me-missing-session'
          ? [403]
          : result.step_key === 'account-select-invalid-org'
            ? [404]
            : [200];
        assert(expectedHttpStatuses.includes(result.http_status), `unexpected HTTP status: ${row.scenario_id}/${result.step_key}/${result.http_status}`);
        assert(JSON.stringify(result.expected_http_statuses) === JSON.stringify(expectedHttpStatuses), `declared expectation mismatch: ${row.scenario_id}/${result.step_key}`);
        assert(result.outcome_matched === true, `route outcome not matched: ${row.scenario_id}/${result.step_key}`);
      } else {
        const resolved = resolveInsideRoot(result.stop_evidence_ref, `${row.scenario_id}/${result.step_key} stop_evidence_ref`);
        assert((await stat(resolved)).isFile(), `${row.scenario_id}: missing stop evidence`);
      }
    }
  }
  const owner = await readJson('responses/owner-aligned-terminal-summary.json');
  assert(owner.owner_alignment?.aligned === true, 'owner alignment is not proven');
  assert(owner.missing_request_id_count === 0, 'owner-aligned request IDs are incomplete');
  for (const key of ['execute_http_status', 'receipt_http_status', 'audit_http_status', 'rollback_http_status', 'takeover_http_status']) {
    assert(owner.commercial_context?.[key] === 200, `owner-aligned ${key} did not pass`);
  }
  process.stdout.write('ten-family scenario matrix gate passed\n');
}

async function validateRuntime() {
  const sanity = await readJson('runtime-sanity.json');
  assert(sanity.marker_parity === true, 'runtime marker parity failed');
  assert(sanity.baseline_stable === true, 'runtime baseline drifted');
  assert(sanity.package_stable === true, 'runtime package markers drifted');
  assert(sanity.review_record_stable === true, 'runtime review record drifted');
  assert(sanity.runtime_identity_state === 'identity_complete', 'runtime identity is incomplete');
  assert(sanity.readiness_degraded === false, 'runtime readiness degraded');
  process.stdout.write('runtime sanity gate passed\n');
}

const sensitiveKey = /^(sessionId|session_id|adminSessionId|admin_session_id|password|claim_token|invitation_token|access_token|refresh_token|authorization|cookie|set-cookie|x-bidvia-session-id|x-bidvia-admin-session-id|email)$/i;

function sanitizeString(value) {
  return value
    .replaceAll(path.resolve(process.cwd()), '[WORKSPACE]')
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[REDACTED_EMAIL]')
    .replace(/\b(?:admin-session|sess)-(?!id\b)[A-Za-z0-9._:-]+\b/g, '[REDACTED]')
    .replace(/\b(?:Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+/gi, '[REDACTED_AUTH]')
    .replace(/\/tmp\/[A-Za-z0-9._/-]+/g, '[TEMP]')
    .replace(/\/var\/folders\/[A-Za-z0-9._/-]+/g, '[TEMP]');
}

function redact(value) {
  if (Array.isArray(value)) return value.map(redact);
  if (typeof value === 'string') return sanitizeString(value);
  if (typeof value !== 'object' || value === null) return value;
  return Object.fromEntries(Object.entries(value).map(([key, nested]) => [
    key,
    sensitiveKey.test(key) && nested !== null ? '[REDACTED]' : redact(nested),
  ]));
}

async function redactAndReviewSecrets() {
  let priorRedactedFields = 0;
  try {
    priorRedactedFields = (await readJson('secret-review.json')).redacted_fields ?? 0;
  } catch {
    priorRedactedFields = 0;
  }
  const files = await listFiles();
  let jsonFilesReviewed = 0;
  let textFilesReviewed = 0;
  let redactedFields = 0;
  for (const absolutePath of files.filter((file) => file.endsWith('.json'))) {
    const raw = await readFile(absolutePath, 'utf8');
    const parsed = JSON.parse(raw);
    const beforeMatches = raw.match(/"(?:sessionId|session_id|adminSessionId|admin_session_id|password|claim_token|invitation_token)"\s*:\s*"(?!\[REDACTED\])[^"\n]+"/gi) ?? [];
    redactedFields += beforeMatches.length;
    await writeFile(absolutePath, `${JSON.stringify(redact(parsed), null, 2)}\n`, { mode: 0o600 });
    jsonFilesReviewed += 1;
  }
  for (const absolutePath of files.filter((file) => !file.endsWith('.json'))) {
    const raw = await readFile(absolutePath, 'utf8');
    await writeFile(absolutePath, sanitizeString(raw), { mode: 0o600 });
    textFilesReviewed += 1;
  }
  const patchPath = path.join(root, 'client-working-tree.patch');
  const sanitizedPatchDigest = createHash('sha256').update(await readFile(patchPath)).digest('hex');
  await writeFile(path.join(root, 'client-working-tree.patch.sha256'), `${sanitizedPatchDigest}  client-working-tree.patch\n`, { mode: 0o600 });
  const reviewedFiles = await listFiles();
  const prohibitedValues = [
    ['pw', 'admin', 'ops'].join('-'),
    ['secret', 'live', '1'].join('-'),
  ];
  const exposed = [];
  for (const absolutePath of reviewedFiles) {
    const content = await readFile(absolutePath, 'utf8');
    for (const [index, prohibited] of prohibitedValues.entries()) {
      if (content.includes(prohibited)) {
        exposed.push({ file: path.relative(root, absolutePath), prohibited_value_class: index === 0 ? 'seeded_admin_password' : 'default_claimant_password' });
      }
    }
    if (absolutePath.endsWith('.json')) {
      const unredacted = content.match(/"(?:sessionId|session_id|adminSessionId|admin_session_id|password|claim_token|invitation_token)"\s*:\s*"(?!\[REDACTED\])[^"\n]+"/gi) ?? [];
      if (unredacted.length > 0) exposed.push({ file: path.relative(root, absolutePath), prohibited_value_class: 'credential_bearing_json_value' });
    }
    const exposurePatterns = [
      ['email_value', /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i],
      ['session_value', /\b(?:admin-session|sess)-(?!id\b)[A-Za-z0-9._:-]+\b/],
      ['authorization_value', /\b(?:Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+/i],
      ['local_user_path', /\/Users\/[A-Za-z0-9._/-]+/],
      ['temporary_path', /\/(?:tmp|var\/folders)\/[A-Za-z0-9._/-]+/],
    ];
    for (const [secretClass, pattern] of exposurePatterns) {
      if (pattern.test(content)) exposed.push({ file: path.relative(root, absolutePath), prohibited_value_class: secretClass });
    }
  }
  const report = {
    status: exposed.length === 0 ? 'passed' : 'failed',
    reviewed_at: new Date().toISOString(),
    json_files_reviewed: jsonFilesReviewed,
    text_files_reviewed: textFilesReviewed,
    redacted_fields: priorRedactedFields + redactedFields,
    exposed_secret_findings: exposed,
    allowed_non_secret_refs: ['secret:// credential references', 'credential key names with redacted values'],
  };
  await writeJson('secret-review.json', report);
  assert(exposed.length === 0, `secret review found ${exposed.length} exposed values`);
  process.stdout.write(`secret review passed; ${redactedFields} fields redacted\n`);
}

async function writeHashes() {
  const hashNames = new Set(['artifact-manifest.sha256', 'SHA256SUMS.txt']);
  const files = (await listFiles()).filter((file) => !hashNames.has(path.basename(file)));
  const lines = [];
  for (const absolutePath of files) {
    const digest = createHash('sha256').update(await readFile(absolutePath)).digest('hex');
    lines.push(`${digest}  ${path.relative(root, absolutePath)}`);
  }
  const manifest = `${lines.join('\n')}\n`;
  await writeFile(path.join(root, 'SHA256SUMS.txt'), manifest, { mode: 0o600 });
  await writeFile(path.join(root, 'artifact-manifest.sha256'), manifest, { mode: 0o600 });
  process.stdout.write(`artifact hash manifest written for ${lines.length} files\n`);
}

async function validatePackageStructure(requireHashes) {
  const requiredFiles = [
    'README.md',
    'terminal-evidence.json',
    'conclusion.md',
    'runtime-sanity.json',
    'static-gates.json',
    'bounded-matrix-raw.json',
    'scenario-matrix.json',
    'defects-or-ambiguities.json',
    'evidence-tooling-manifest.json',
    'core-activation.json',
    'client-commit.txt',
    'client-branch.txt',
    'client-upstream.txt',
    'client-upstream.err',
    'client-status.txt',
    'client-package.txt',
    'client-untracked-files.txt',
    'client-untracked-files.sha256',
    'client-behavior-untracked-files.txt',
    'client-working-tree.patch',
    'client-working-tree.patch.sha256',
    'logs/validation-commands.json',
    'secret-review.json',
  ];
  if (requireHashes) requiredFiles.push('SHA256SUMS.txt', 'artifact-manifest.sha256');
  for (const relativePath of requiredFiles) {
    assert((await stat(path.join(root, relativePath))).isFile(), `missing required package file: ${relativePath}`);
  }
  const behaviorList = (await readFile(path.join(root, 'client-behavior-untracked-files.txt'), 'utf8')).trim().split('\n').filter(Boolean);
  const frozenUntracked = new Set((await readFile(path.join(root, 'client-untracked-files.txt'), 'utf8')).trim().split('\n').filter(Boolean));
  for (const relativePath of behaviorList) {
    assert(frozenUntracked.has(relativePath), `behavior-affecting path was not present in the frozen untracked inventory: ${relativePath}`);
  }
  const behaviorCopies = await listFiles(path.join(root, 'untracked-behavior-deltas'));
  assert(behaviorCopies.length === behaviorList.length, 'behavior delta copy count does not match inventory');
  const defects = await readJson('defects-or-ambiguities.json');
  assert(Array.isArray(defects.unresolved) && defects.unresolved.length === 0, 'unresolved defects or ambiguities remain');
  const secretReview = await readJson('secret-review.json');
  assert(secretReview.status === 'passed' && secretReview.exposed_secret_findings.length === 0, 'secret review is not clean');
  process.stdout.write(`package structure gate passed${requireHashes ? ' with hashes' : ''}\n`);
}

async function verifyHashes() {
  const manifest = await readFile(path.join(root, 'SHA256SUMS.txt'), 'utf8');
  const alias = await readFile(path.join(root, 'artifact-manifest.sha256'), 'utf8');
  assert(manifest === alias, 'hash manifests differ');
  for (const line of manifest.trim().split('\n')) {
    const match = /^([a-f0-9]{64})  (.+)$/.exec(line);
    assert(match, `invalid hash line: ${line}`);
    const [, expected, relativePath] = match;
    const absolutePath = resolveInsideRoot(relativePath, 'hash manifest');
    const actual = createHash('sha256').update(await readFile(absolutePath)).digest('hex');
    assert(actual === expected, `hash mismatch: ${relativePath}`);
  }
  process.stdout.write('hash manifest verification passed\n');
}

if (mode === 'matrix') await validateMatrix();
else if (mode === 'runtime') await validateRuntime();
else if (mode === 'secret') await redactAndReviewSecrets();
else if (mode === 'hash') await writeHashes();
else if (mode === 'package') await validatePackageStructure(false);
else if (mode === 'package-final') await validatePackageStructure(true);
else if (mode === 'verify-hash') await verifyHashes();
else throw new Error(`unknown validation mode: ${mode}`);
