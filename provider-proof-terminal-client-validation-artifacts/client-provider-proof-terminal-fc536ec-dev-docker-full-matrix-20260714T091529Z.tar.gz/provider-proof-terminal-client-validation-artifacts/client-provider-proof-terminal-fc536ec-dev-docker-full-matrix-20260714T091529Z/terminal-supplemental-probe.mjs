import { randomUUID } from 'node:crypto';
import { chmod, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const evidenceRoot = path.dirname(fileURLToPath(import.meta.url));
const responsesRoot = path.join(evidenceRoot, 'responses');
const runtimeBaseUrl = 'http://127.0.0.1:59788';
const tenantId = 'tenant-public';
const secretKeyPattern = /(?:password|session.?id|access.?token|refresh.?token|invitation.?token|claim.?token|authorization|cookie|jwt.?secret|bearer|email)/iu;
const secretValuePattern = /\b(?:sess|admin-session)-[A-Za-z0-9-]+\b/gu;

function asObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) ? value : {};
}

function readPath(value, segments) {
  let current = value;
  for (const segment of segments) current = asObject(current)[segment];
  return current;
}

function readString(value) {
  return typeof value === 'string' && value.length > 0 ? value : null;
}

function sanitize(value, key = '') {
  if (secretKeyPattern.test(key)) return '[REDACTED]';
  if (Array.isArray(value)) return value.map((item) => sanitize(item));
  if (value !== null && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value).map(([childKey, childValue]) => [childKey, sanitize(childValue, childKey)]),
    );
  }
  if (typeof value === 'string') return value.replace(secretValuePattern, '[REDACTED]');
  return value;
}

function collectTraceIds(value, result = new Set()) {
  if (Array.isArray(value)) {
    for (const item of value) collectTraceIds(item, result);
    return result;
  }
  if (value !== null && typeof value === 'object') {
    for (const [key, child] of Object.entries(value)) {
      if ((key === 'trace_id' || key === 'traceId') && typeof child === 'string' && child.length > 0) {
        result.add(child);
      }
      collectTraceIds(child, result);
    }
  }
  return result;
}

async function writePrivate(filePath, value) {
  await writeFile(filePath, `${JSON.stringify(value, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 });
  await chmod(filePath, 0o600);
}

const requestRecords = [];

async function requestStep(stepKey, method, routeTemplate, route, authHeaderClass, headers = {}, requestBody = null) {
  const startedAt = new Date().toISOString();
  let response;
  let responseBody = null;
  let error = null;
  try {
    response = await fetch(`${runtimeBaseUrl}${route}`, {
      method,
      headers,
      ...(requestBody === null ? {} : { body: JSON.stringify(requestBody) }),
    });
    const text = await response.text();
    try {
      responseBody = text.length > 0 ? JSON.parse(text) : null;
    } catch (parseError) {
      responseBody = { raw_text: text };
      error = parseError instanceof Error ? { name: parseError.name, message: parseError.message } : { message: String(parseError) };
    }
  } catch (fetchError) {
    error = fetchError instanceof Error ? { name: fetchError.name, message: fetchError.message } : { message: String(fetchError) };
  }

  const requestId = response?.headers.get('x-request-id') ?? null;
  const evidenceRef = `responses/${stepKey}.json`;
  const record = {
    step_key: stepKey,
    method,
    route: routeTemplate,
    actual_path: route,
    reached_http: response !== undefined,
    started_at: startedAt,
    finished_at: new Date().toISOString(),
    http_status: response?.status ?? 0,
    response_class: response && response.status >= 200 && response.status < 300 ? 'passed' : 'fail_closed_or_failed',
    response_headers: { 'x-request-id': requestId },
    auth_header_class: authHeaderClass,
    request_body: sanitize(requestBody),
    response_body: sanitize(responseBody),
    trace_ids: [...collectTraceIds({ requestBody, responseBody })],
    evidence_ref: evidenceRef,
    error,
  };
  requestRecords.push(record);
  await writePrivate(path.join(evidenceRoot, evidenceRef), record);
  return { ...record, rawResponseBody: responseBody };
}

async function main() {
  const operator = JSON.parse(await readFile(path.join(evidenceRoot, 'bounded-matrix-artifacts', 'bounded-matrix-operator-report.json'), 'utf8'));
  const platform = JSON.parse(await readFile(path.join(evidenceRoot, 'bounded-matrix-artifacts', 'bounded-matrix-platform-managed-report.json'), 'utf8'));
  const packB = JSON.parse(await readFile(path.join(evidenceRoot, 'bounded-matrix-artifacts', 'bounded-matrix-pack-b-report.json'), 'utf8'));

  const claimant = asObject(readPath(platform, ['bootstrap', 'claimant']));
  const admin = asObject(readPath(platform, ['bootstrap', 'admin']));
  const packClaimant = asObject(readPath(packB, ['bootstrap', 'claimant']));
  const claimantSessionId = readString(claimant.sessionId);
  const adminSessionId = readString(admin.adminSessionId);
  const activeOrgId = readString(claimant.companyId);
  const claimantAgentId = readString(claimant.agentId);
  const claimantRegistrationId = readString(claimant.registrationId);
  const packSessionId = readString(packClaimant.sessionId);
  const packAgentId = readString(packClaimant.agentId);
  const successDispatchId = readString(readPath(packB, ['successBranch', 'dispatchId']));
  const packageId = readString(readPath(operator, ['ids', 'packageId']));
  const opportunityId = readString(readPath(operator, ['ids', 'opportunityId']));
  const connectionApprovalRequestId = readString(readPath(operator, ['ids', 'connectionApprovalRequestId']));
  const platformAgentId = readString(platform.platformManagedAgentId);
  const platformRegistrationStep = Array.isArray(platform.steps)
    ? platform.steps.find((step) => asObject(step).stepKey === 'platform-managed-registration')
    : null;
  const platformRegistrationId = readString(readPath(platformRegistrationStep, ['responseBody', 'registration', 'agent_registration_id']));

  if (!claimantSessionId || !adminSessionId || !activeOrgId || !claimantAgentId || !claimantRegistrationId || !packSessionId || !packAgentId || !successDispatchId || !packageId || !opportunityId || !connectionApprovalRequestId || !platformAgentId || !platformRegistrationId) {
    throw new Error('supplemental probe context is incomplete');
  }

  const claimantHeaders = { 'content-type': 'application/json', 'x-bidvia-session-id': claimantSessionId };
  const packHeaders = { 'content-type': 'application/json', 'x-bidvia-session-id': packSessionId };
  const adminHeaders = { 'content-type': 'application/json', 'x-bidvia-admin-session-id': adminSessionId };

  await requestStep('account-me', 'GET', '/runtime/account/me', '/runtime/account/me', 'claimant_session', { 'x-bidvia-session-id': claimantSessionId });
  await requestStep('account-me-missing-session', 'GET', '/runtime/account/me', '/runtime/account/me', 'none');
  await requestStep('account-select-invalid-org', 'POST', '/runtime/account/select-org', '/runtime/account/select-org', 'claimant_session', claimantHeaders, {
    org_id: `org-not-member-${randomUUID()}`,
    now: new Date().toISOString(),
  });
  await requestStep('account-select-active-org', 'POST', '/runtime/account/select-org', '/runtime/account/select-org', 'claimant_session', claimantHeaders, {
    org_id: activeOrgId,
    now: new Date().toISOString(),
  });

  const provisionalRef = `prov-terminal-${randomUUID()}`;
  const provisionalCreate = await requestStep('provisional-agent-create', 'POST', '/runtime/agents/provisional', '/runtime/agents/provisional', 'public', { 'content-type': 'application/json' }, {
    provisional_agent_ref: provisionalRef,
    now: new Date().toISOString(),
  });
  const returnedProvisionalRef = readString(readPath(provisionalCreate.rawResponseBody, ['provisional_agent_ref'])) ?? provisionalRef;
  const provisionalQuery = await requestStep('provisional-agent-query', 'GET', '/runtime/agents/provisional', `/runtime/agents/provisional?provisional_agent_ref=${encodeURIComponent(returnedProvisionalRef)}`, 'public');
  const claimToken = readString(readPath(provisionalCreate.rawResponseBody, ['claim_token']))
    ?? readString(readPath(provisionalQuery.rawResponseBody, ['provisional_agent', 'claim_token']));
  if (!claimToken) throw new Error('supplemental provisional claim token missing');
  await requestStep('provisional-agent-claim', 'POST', '/runtime/agents/provisional/claim', '/runtime/agents/provisional/claim', 'claimant_session', claimantHeaders, {
    provisional_agent_ref: returnedProvisionalRef,
    claim_token: claimToken,
    now: new Date().toISOString(),
  });

  const taskRoot = `/runtime/account/agents/${encodeURIComponent(packAgentId)}/task-dispatches/${encodeURIComponent(successDispatchId)}`;
  await requestStep('task-dispatch-readback', 'GET', '/runtime/account/agents/:agentId/task-dispatches/:taskDispatchId', `${taskRoot}?tenant_id=${encodeURIComponent(tenantId)}`, 'claimant_session', packHeaders);
  await requestStep('governed-work-closure-readback', 'GET', '/runtime/account/agents/:agentId/task-dispatches/:taskDispatchId/governed-work-closure', `${taskRoot}/governed-work-closure?tenant_id=${encodeURIComponent(tenantId)}`, 'claimant_session', packHeaders);

  await requestStep('platform-managed-eligibility-readback', 'GET', '/runtime/account/agents/:agentId/integrations/:integrationCode/eligibility', `/runtime/account/agents/${encodeURIComponent(platformAgentId)}/integrations/haisi-wms/eligibility`, 'claimant_session', claimantHeaders);
  const linkedInbound = await requestStep('provider-linked-inbound', 'POST', '/runtime/account/agents/:agentId/integrations/haisi-wms/inbound', `/runtime/account/agents/${encodeURIComponent(platformAgentId)}/integrations/haisi-wms/inbound`, 'claimant_session', claimantHeaders, {
    warehouseId: 40,
    date: '2026-03-16',
    details: [],
    opportunity_package_id: packageId,
    opportunity_id: opportunityId,
    now: new Date().toISOString(),
  });
  const providerReceiptId = readString(readPath(linkedInbound.rawResponseBody, ['receipt', 'provider_receipt_id']));
  const providerProofId = readString(readPath(linkedInbound.rawResponseBody, ['receipt', 'provider_proof_id']));
  const providerTraceId = readString(readPath(linkedInbound.rawResponseBody, ['receipt', 'trace_id']));

  const commercialTraceId = `trace-commercial-${randomUUID()}`;
  const commercialCreate = await requestStep('commercial-action-create', 'POST', '/runtime/commercial-actions', `/runtime/commercial-actions?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
    governed_action: 'EXTERNAL_WRITE',
    subject_type: 'OPPORTUNITY_PACKAGE',
    subject_id: packageId,
    trace_id: commercialTraceId,
    workflow_id: 'WF-PROVIDER-PROOF-TERMINAL',
    now: new Date().toISOString(),
  });
  const commercialRequestId = readString(readPath(commercialCreate.rawResponseBody, ['request', 'commercial_action_request_id']));
  if (!commercialRequestId) throw new Error('commercial action request was not created');

  await requestStep('commercial-action-policy-check', 'POST', '/runtime/commercial-actions/:commercialActionRequestId/policy-check', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/policy-check?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
    policy_version: 'policy-external-write-connector-v1',
    outcome: 'APPROVAL_REQUIRED',
    now: new Date().toISOString(),
  });
  await requestStep('commercial-action-request-approval', 'POST', '/runtime/commercial-actions/:commercialActionRequestId/request-approval', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/request-approval?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
    approval_request_id: connectionApprovalRequestId,
    now: new Date().toISOString(),
  });
  const commercialExecute = await requestStep('commercial-action-execute', 'POST', '/runtime/commercial-actions/:commercialActionRequestId/execute', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/execute?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
    approval_request_id: connectionApprovalRequestId,
    integration_code: 'haisi-wms',
    receipt_id: providerReceiptId ?? `receipt-terminal-${randomUUID()}`,
    approval_result: 'APPROVED',
    result_status: 'SUCCEEDED',
    audit_id: `audit-terminal-${randomUUID()}`,
    now: new Date().toISOString(),
  });
  await requestStep('commercial-action-status', 'GET', '/runtime/commercial-actions/:commercialActionRequestId/status', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/status?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders);
  await requestStep('commercial-action-receipt', 'GET', '/runtime/commercial-actions/:commercialActionRequestId/receipt', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/receipt?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders);
  await requestStep('commercial-action-audit', 'GET', '/runtime/commercial-actions/:commercialActionRequestId/audit', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/audit?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders);
  const commercialRollback = await requestStep('commercial-action-rollback', 'POST', '/runtime/commercial-actions/:commercialActionRequestId/rollback', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/rollback?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
    receipt_id: providerReceiptId,
    rollback_reason: 'client-owned dev-docker provider-proof terminal rollback continuity check',
    now: new Date().toISOString(),
  });
  await requestStep('commercial-action-takeover', 'POST', '/runtime/commercial-actions/:commercialActionRequestId/takeover', `/runtime/commercial-actions/${encodeURIComponent(commercialRequestId)}/takeover?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
    reason: 'client-owned dev-docker provider-proof terminal takeover check',
    now: new Date().toISOString(),
  });

  const operatorTakeover = await requestStep('operator-agent-takeover', 'POST', '/operator/agents/:registrationId/takeover', `/operator/agents/${encodeURIComponent(claimantRegistrationId)}/takeover?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
    reason: 'client-owned dev-docker provider-proof terminal owner-correct takeover check',
    now: new Date().toISOString(),
  });
  const takeoverControlActionId = readString(readPath(operatorTakeover.rawResponseBody, ['control_action', 'agent_control_action_id']))
    ?? readString(readPath(operatorTakeover.rawResponseBody, ['control_action', 'control_action_id']));
  await requestStep('operator-recovery-record', 'POST', '/operator/agents/:registrationId/recovery-records', `/operator/agents/${encodeURIComponent(claimantRegistrationId)}/recovery-records?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
    triggered_by_control_action_ids: takeoverControlActionId ? [takeoverControlActionId] : [],
    recovery_task_ref: `task:provider-proof-terminal-${randomUUID()}`,
    recovery_policy_ref: 'policy:provider-proof-terminal-dev-docker',
    evidence_bundle_refs: [`evidence:bundle:provider-proof-terminal-${providerProofId ?? randomUUID()}`],
    confirmation_cycle_ref: `confirmation-cycle:provider-proof-terminal-${randomUUID()}`,
    dispute_ref: `dispute:provider-proof-terminal-${randomUUID()}`,
    sla_window_ref: 'policy:provider-proof-terminal-dev-docker::sla:local',
    recovery_lineage_refs: [providerProofId ? `provider-proof:${providerProofId}` : 'provider-proof:missing'],
    recovered_by_actor_family: 'PLATFORM_MANAGED_AGENT',
    recovered_participation_state: 'verified_for_validation',
    recovery_kind: 'POST_DOWNGRADE_REENTRY',
    recovered_at: new Date().toISOString(),
    recovery_reason: 'client-owned dev-docker provider-proof terminal recovery continuity check',
  });
  await requestStep('operator-takeover-reassignment', 'POST', '/operator/agents/:registrationId/takeover-reassignments', `/operator/agents/${encodeURIComponent(claimantRegistrationId)}/takeover-reassignments?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders, {
    to_agent_registration_id: platformRegistrationId,
    reassignment_ref: `commercial-action:${commercialRequestId}`,
    reassignment_kind: 'COMMERCIAL_ACTION_REVIEW',
    takeover_decision: 'REASSIGN_TO_HEALTHIER_AGENT',
    discipline_reason: 'client-owned dev-docker provider-proof terminal reassignment check',
    recorded_at: new Date().toISOString(),
  });
  const operatorControlState = await requestStep('operator-control-state', 'GET', '/operator/agents/:registrationId/control-state', `/operator/agents/${encodeURIComponent(claimantRegistrationId)}/control-state?tenant_id=${encodeURIComponent(tenantId)}`, 'operator_admin', adminHeaders);

  await requestStep('runtime-healthz-supplemental', 'GET', '/healthz', '/healthz', 'none');
  await requestStep('runtime-readyz-supplemental', 'GET', '/readyz', '/readyz', 'none');

  const summary = {
    generated_at: new Date().toISOString(),
    runtime_base_url: runtimeBaseUrl,
    actor_context: {
      active_org_id: activeOrgId,
      claimant_agent_id: claimantAgentId,
      claimant_registration_id: claimantRegistrationId,
      platform_managed_agent_id: platformAgentId,
      platform_managed_registration_id: platformRegistrationId,
      distinct_agent_identity: claimantAgentId !== platformAgentId,
      distinct_registration_identity: claimantRegistrationId !== platformRegistrationId,
      session_source: 'core_issued_claimant_session',
      operator_session_source: 'core_issued_admin_session',
    },
    opportunity_context: { opportunity_id: opportunityId, opportunity_package_id: packageId },
    provider_context: { provider_receipt_id: providerReceiptId, provider_proof_id: providerProofId, provider_trace_id: providerTraceId },
    commercial_context: {
      commercial_action_request_id: commercialRequestId,
      execute_http_status: commercialExecute.http_status,
      rollback_http_status: commercialRollback.http_status,
      trace_id: commercialTraceId,
    },
    recovery_context: {
      control_state_http_status: operatorControlState.http_status,
      recovery_continuity_state: readPath(operatorControlState.rawResponseBody, ['recovery_continuity_state']) ?? null,
      takeover_continuity_state: readPath(operatorControlState.rawResponseBody, ['takeover_continuity_state']) ?? null,
      reassignment_continuity_state: readPath(operatorControlState.rawResponseBody, ['reassignment_continuity_state']) ?? null,
    },
    request_records: requestRecords,
    secret_handling: { persisted_header_values: false, persisted_raw_credentials: false },
  };
  await writePrivate(path.join(responsesRoot, 'terminal-supplemental-summary.json'), sanitize(summary));
  process.stdout.write(`${JSON.stringify({
    request_count: requestRecords.length,
    missing_request_id_count: requestRecords.filter((record) => record.reached_http && !record.response_headers['x-request-id']).length,
    provider_receipt_id: providerReceiptId,
    provider_proof_id: providerProofId,
    commercial_action_request_id: commercialRequestId,
    commercial_execute_http_status: commercialExecute.http_status,
    commercial_rollback_http_status: commercialRollback.http_status,
    recovery_control_state_http_status: operatorControlState.http_status,
    evidence_ref: 'responses/terminal-supplemental-summary.json',
  }, null, 2)}\n`);
}

await main();
